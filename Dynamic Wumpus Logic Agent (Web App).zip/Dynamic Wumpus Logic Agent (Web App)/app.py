from flask import Flask, render_template, jsonify
import random

app = Flask(__name__)

DIRECTIONS = [(-1,0),(1,0),(0,-1),(0,1)]


class WumpusWorld:
    def __init__(self, rows, cols):
        self.rows = rows
        self.cols = cols
        self.grid = [['.' for _ in range(cols)] for _ in range(rows)]
        self.safe_cells = [(0, 0)]
        self.agent = [0, 0]
        self.inference_steps = 0
        self.place_hazards()

    def place_hazards(self):
        self.danger = []

        # Place Wumpus
        while True:
            x = random.randint(0, self.rows - 1)
            y = random.randint(0, self.cols - 1)
            if (x, y) != (0, 0):
                self.grid[x][y] = 'W'
                self.danger.append((x, y))
                break

        # Place pits
        pit_count = (self.rows * self.cols) // 5
        count = 0
        while count < pit_count:
            x = random.randint(0, self.rows - 1)
            y = random.randint(0, self.cols - 1)
            if self.grid[x][y] == '.' and (x, y) != (0, 0):
                self.grid[x][y] = 'P'
                self.danger.append((x, y))
                count += 1

    def get_percepts(self, x, y):
        percepts = []
        for dx, dy in DIRECTIONS:
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.rows and 0 <= ny < self.cols:
                if self.grid[nx][ny] == 'P':
                    percepts.append("Breeze")
                if self.grid[nx][ny] == 'W':
                    percepts.append("Stench")
        return percepts

    def move_agent(self):
        self.inference_steps += 1

        x, y = self.agent
        neighbors = []

        for dx, dy in DIRECTIONS:
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.rows and 0 <= ny < self.cols:
                neighbors.append((nx, ny))

        if neighbors:
            self.agent = list(random.choice(neighbors))
            if tuple(self.agent) not in self.safe_cells:
                self.safe_cells.append(tuple(self.agent))

    def state(self):
        self.move_agent()

        return {
            "rows": self.rows,
            "cols": self.cols,
            "safe": self.safe_cells,
            "danger": self.danger,
            "agent": self.agent,
            "percepts": self.get_percepts(self.agent[0], self.agent[1]),
            "steps": self.inference_steps
        }


world = WumpusWorld(4, 4)


@app.route('/')
def home():
    return render_template("index.html")


@app.route('/state')
def get_state():
    return jsonify(world.state())


if __name__ == '__main__':
    app.run(debug=True)